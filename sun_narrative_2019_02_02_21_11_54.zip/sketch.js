var sunSlider;
var canvas;
var greeting;
var title;
var firstOption;
var secondOption;
var controlSunBool = false;
var inputName;


function setup() {
  canvas = createCanvas(800, 600);
  canvas.position(0,0);
}

function draw() {
 if(controlSunBool == true) {
   controlSunAnim();
 }
}

function startNarrative() {
  background(0);
  greeting = createP("Please type your name and press enter:");
  nameInput = createInput();
  nameInput.changed(page1);
}

function closerSun() {
  firstOption.hide();
  secondOption.hide();
  title.html(nameInput.value() + ', drifting towards the sun');
}

function controlSun() {
  controlSunBool = true;
  firstOption.hide();
  secondOption.hide();
  
  sunSlider = createSlider(0, 255, 0);
  sunSlider.addClass('slider');
}

function controlSunAnim() {
	background(135, 114, 37);
  
  fill(sunSlider.value(), 0, 0);
  ellipse(width/2, height/2, sunSlider.value() * 2, sunSlider.value() * 2);

	if(sunSlider.value() > 150) {
    title.html('the sun is too hot!');
  }
  else {
    title.html('make the sun bigger!');
  }
}