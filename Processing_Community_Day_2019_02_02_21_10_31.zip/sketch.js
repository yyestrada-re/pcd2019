var mic;

var Patient;

function preload() {
	Patient = loadSound('Patient.mp3');
}

function setup() { //initial setup (.init())?
  createCanvas(800, 800);// x and y values = argument
	
	mic = new p5.AudioIn()
  mic.start();
	
	Patient.play();
	
}

function draw() { //what's changing over time
	micLevel = mic.getLevel();
	
	let newColor = map(mouseX,0,width,0,255);
	
	let newVolume = map(micLevel, 0, 0.1, 100, 200);
	
  background(178,newColor,newVolume); //where parameter is RGB value

	push(); //the following commands are limited to this code segment only
	stroke(255);
	fill(178,120,101);
	rect(50,mouseY,150,150); //placement of shapes matters
	pop();
	
	stroke(255);
	strokeWeight(10);
	fill(0,0,150);
	ellipse(mouseX,200,newVolume, newVolume);
	
	print(newVolume);
}